<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php wp_head(); ?>
</head>
<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
				<?php
					// if(current_theme_supports("custom-logo"));
				?>
				<div class="header-logo text-center">
					<?php the_custom_logo(); ?>
				</div>
				<?php
				// endif;
				?>
                <h3 class="tagline">
                    <?php bloginfo( "description" ); ?>
                </h3>
                <h1 class="align-self-center display-1 text-center heading">
                    <a href="<?php echo site_url(); ?>"><?php bloginfo( "name" ); ?></a>
                </h1>
            </div>		
        </div>
    </div>
</div>
<!--------navigation----------->
<div class="container">
	<div class="row">
			<div class="col-md-12">
				<div class="navigation">
					<?php
						wp_nav_menu( array(
							'theme_location'    => "topmenu", 
							'menu_class'        => "list-inline text-center", 
							'menu_id'           => "topmenucontainer",         													   
						)
						);
					?>
				</div>
			</div>
	</div>
</div>

<!-------search form---------->
<div class="container">
	<div class="row">
		<div class="col-md-12 text-right">
			<?php 
				if(is_search()){
			?>
			<h2> <?php _e('You Searched for','alpha'); ?> : <?php the_search_query(); ?></h2>
			<?php 
			}
			?>									
			<?php
				echo get_search_form();
			?>
		</div>
	</div>
</div>








