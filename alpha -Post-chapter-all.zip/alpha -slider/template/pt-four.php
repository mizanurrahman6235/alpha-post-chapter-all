<?php 
	echo "<br />PT Four Welcome four<br />";
	
?>
<?php get_template_part("pt-five"); ?>