<?php get_header(); ?>
<body <?php body_class(); ?>>
<div class="posts">
    <?php	
	// start search no post found
	if(!have_posts()){	
	?>
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center search-no-result">
				<h4>
					<?php _e('No Result Found ! Please try another one.','alpha'); ?>
				</h4>
			</div>
		</div>
	</div>
	<?php	
	}
	// end search no post found	
	
	// start post
    while(have_posts()){
        the_post();
		get_template_part("post-formats/content", get_post_format());
		}
    ?>	  
    <div class="container post-pagination">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-8">
                <?php
                the_posts_pagination( array(
                    "screen_reader_text" => ' ',
                    "prev_text"          => "New Posts",
                    "next_text"          => "Old Posts"
                ) );
                ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>